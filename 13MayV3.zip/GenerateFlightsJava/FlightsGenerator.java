package com.company;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.UUID;

public class FlightsGenerator {
    public void generateFlights() {
        String flights = "[";

        for (int i=0; i<1200; i++) {
            String from = UUID.randomUUID().toString().replace("-", "");
            String to = UUID.randomUUID().toString().replace("-", "");
            Random rand = new Random(); //instance of random class
            int upperbound = 15;
            //generate random values from 0-24
            int int_random = rand.nextInt(upperbound);

            flights += "{:id "+ i + " \n" +
                    "    :from \"" + from + "\" :to \""+ to +"\" \n" +
                    "    :carrier \"Carrier_"+ int_random +"\" \n" +
                    "    :pricing [\n" +
                    "        [100 15000 0]\n" +
                    "        [150  5000 0]\n" +
                    "        [200  5000 0]\n" +
                    "        [300  5000 0]]\n" +
                    "    }";
        }
        flights += "]";

        try {
            FileWriter myWriter = new FileWriter("flights.txt");
            myWriter.write(flights);
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
